# Watch Valuation — Supabase + Cloudflare Worker + React (Vite)

A sleek single-page app to estimate a watch’s market value from comparable sales, with:
- Fast search (brand/model/reference)
- CSV upload (eBay “Sold/Completed” exports or any normalized CSV)
- Comps list (with source badges)
- Robust estimate using median + IQR outlier trimming
- Optional Supabase backend + Cloudflare Worker API
- FX conversion via ExchangeRate.host (server-side proxy route)

## Quick Start (Frontend only, with CSV upload)
```bash
cd app
npm install
npm run dev
```
Click **Developer → CSV Upload**, drop a CSV, and the comps will render/estimate immediately.

**CSV columns supported (any order)**:
- `brand` (e.g., Rolex)
- `model` (e.g., Datejust)
- `reference` (e.g., 116234)
- `title` (listing title)
- `price` (numeric)
- `currency` (e.g., USD, AUD, EUR)
- `date` (ISO or parseable date)
- `condition` (e.g., New, Like New, Very Good, Good, Fair)
- `box_papers` (true/false/yes/no/1/0)
- `bracelet` (e.g., Oyster, Jubilee, Rubber, Leather)
- `source` (eBay, Reddit, Gumtree, Facebook, etc.)
- `url` (listing link)

## Full Stack (Worker + Supabase)
### 1) Supabase
- Create a new project, then run the SQL in `supabase/schema.sql` and `supabase/policies.sql`.
- Load sample data from `supabase/sample_data/comps_sample.csv` if desired.

### 2) Cloudflare Worker
- Install Wrangler: `npm i -g wrangler`
- In `worker/wrangler.toml`, set `SUPABASE_URL` and `SUPABASE_ANON_KEY` (or service role key for protected endpoints).
- `cd worker` then `npm install` and `npm run dev` (or `wrangler dev`).

**Endpoints:**
- `GET /api/comps?brand=&model=&ref=&since=&limit=100` → normalized comps JSON.
- `POST /api/comps/bulk` → upsert CSV-normalized comps (use with care).
- `GET /api/fx?base=AUD&symbols=USD,EUR` → ExchangeRate.host proxy.

### 3) Frontend → Worker
- In `app/.env`, set `VITE_API_BASE` to your Worker URL (e.g., `http://127.0.0.1:8787`).

## Notes on Data Sources & ToS
- eBay: use official APIs or your own account’s export. Do **not** scrape sites that prohibit it.
- Reddit: use Reddit API (e.g., r/Watchexchange). Respect rate limits and terms.
- Facebook Marketplace & Gumtree: rely on permitted exports/partner programs (avoid scraping).

## Dev Commands
**Frontend**
```bash
cd app
npm install
npm run dev       # local dev
npm run build     # prod build
npm run preview   # preview build
```

**Worker**
```bash
cd worker
npm install
npm run dev       # local dev
npm run deploy    # requires Cloudflare account
```

## License
MIT – use freely. Please keep attribution in the README.
