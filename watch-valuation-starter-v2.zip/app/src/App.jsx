import React, { useMemo, useState } from 'react'
import SearchBar from './components/SearchBar'
import EstimateCard from './components/EstimateCard'
import CompsTable from './components/CompsTable'
import CSVUpload from './components/CSVUpload'
import BulkUploader from './components/BulkUploader'
import { robustEstimate } from './lib/valuation'
import { fetchComps } from './lib/api'

export default function App(){
  const [query, setQuery] = useState({brand:'', model:'', ref:''})
  const [comps, setComps] = useState([])
  const [loading, setLoading] = useState(false)
  const [developer, setDeveloper] = useState(false)

  const estimate = useMemo(()=> robustEstimate(comps), [comps])

  const onSearch = async () => {
    setLoading(true)
    try {
      const data = await fetchComps(query)
      setComps(data?.items ?? [])
    } catch(e){
      console.error(e)
      alert('Error fetching comps. Open Developer → CSV Upload to load your own data.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container">
      <div className="header">
        <div className="badge">Beta</div>
        <div className="app-title">Watch Valuation</div>
      </div>

      <SearchBar query={query} setQuery={setQuery} onSearch={onSearch} loading={loading} />

      <div className="row">
        <div className="col">
          <EstimateCard estimate={estimate} />
          <div className="dev-panel">
            <button className="button" onClick={()=>setDeveloper(v=>!v)}>
              {developer ? 'Hide Developer' : 'Developer'}
            </button>
            <span className="small">Paste JSON or upload CSV (eBay Sold exports, Reddit, Gumtree, Facebook).</span>
          </div>
          {developer && <><CSVUpload onLoad={(rows)=> setComps(rows)} /><BulkUploader /></>}
        </div>
        <div className="col">
          <CompsTable items={comps} />
        </div>
      </div>

      <div className="footer">
        Use official APIs/exports. Avoid scraping where prohibited. This tool provides an **estimate**, not financial advice.
      </div>
    </div>
  )
}
