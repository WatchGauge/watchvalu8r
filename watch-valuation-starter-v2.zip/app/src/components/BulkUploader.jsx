import React, { useState } from 'react'
import Papa from 'papaparse'
import { normalizeRows } from '../lib/valuation'
import { bulkUpload } from '../lib/api'

export default function BulkUploader(){
  const [status, setStatus] = useState('Idle')
  const [error, setError] = useState('')

  const onFile = (file) => new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (res) => resolve(res.data || []),
      error: (err) => reject(err)
    })
  })

  const handleUpload = async (e) => {
    const f = e.target.files?.[0]
    if(!f) return
    setError(''); setStatus('Parsing CSV…')
    try{
      const rows = normalizeRows(await onFile(f))
      if(!rows.length) { setStatus('No rows found'); return }
      setStatus(`Uploading ${rows.length} rows…`)
      const ok = await bulkUpload(rows)
      setStatus(ok ? 'Uploaded ✔' : 'Upload failed')
      if(!ok) setError('Server error or not authorized (check service key in Worker).')
    }catch(err){
      setStatus('Error'); setError(String(err?.message||err))
    }
  }

  return (
    <div className="card">
      <div className="small">CSV → Supabase Bulk Upload</div>
      <input type="file" accept=".csv" onChange={handleUpload} />
      <div className="small">Status: {status}</div>
      {error && <div className="small" style={{color:'#fda4af'}}>{error}</div>}
      <div className="small">Note: requires Worker to be configured with <code>SUPABASE_SERVICE_ROLE</code> for writes.</div>
    </div>
  )
}
