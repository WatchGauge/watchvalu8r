import React, { useRef, useState } from 'react'
import Papa from 'papaparse'
import { normalizeRows } from '../lib/valuation'

export default function CSVUpload({onLoad}){
  const [text, setText] = useState('')
  const inputRef = useRef()

  const handleFiles = (files) => {
    const f = files?.[0]
    if(!f) return
    Papa.parse(f, {
      header: true,
      skipEmptyLines: true,
      complete: (res) => {
        const rows = normalizeRows(res.data || [])
        onLoad(rows)
      },
      error: (err) => alert('CSV parse error: ' + err.message)
    })
  }

  const handleJSON = () => {
    try {
      const obj = JSON.parse(text)
      const rows = Array.isArray(obj) ? obj : (obj.items || [])
      onLoad(normalizeRows(rows))
    } catch(e){
      alert('Invalid JSON')
    }
  }

  return (
    <div className="card">
      <div className="small">CSV Upload / JSON Paste</div>
      <div style={{display:'flex', gap:12, alignItems:'center', marginTop:8}}>
        <input type="file" accept=".csv" ref={inputRef}
          onChange={e=>handleFiles(e.target.files)} />
        <button className="button" onClick={()=>{
          if(inputRef.current) inputRef.current.value=null
        }}>Reset</button>
      </div>
      <textarea className="input" rows={6} placeholder='Or paste JSON like {"items":[...]}' value={text}
        onChange={(e)=>setText(e.target.value)} />
      <button className="button" onClick={handleJSON}>Load JSON</button>
    </div>
  )
}
