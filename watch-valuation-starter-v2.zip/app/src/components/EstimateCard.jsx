import React from 'react'

function formatCurrency(v, c='USD'){
  if(v==null) return '—'
  try {
    return new Intl.NumberFormat(undefined,{style:'currency', currency:c}).format(v)
  } catch {
    return `$${v.toFixed(0)} ${c}`
  }
}

export default function EstimateCard({estimate}){
  const {currency='USD', mid, low, high, confidence, count} = estimate || {}
  return (
    <div className="card">
      <div className="small">Estimated Market Value</div>
      <div className="kpi">{formatCurrency(mid, currency)}</div>
      <div className="range">
        <span className="pill">{formatCurrency(low, currency)}</span>
        <span className="small">to</span>
        <span className="pill">{formatCurrency(high, currency)}</span>
      </div>
      <div className={`small confidence ${confidence?.toLowerCase()}`}
           title="Based on number of comps and dispersion after IQR trimming">
        Confidence: {confidence || '—'} ({count || 0} comps)
      </div>
    </div>
  )
}
