import React from 'react'

export default function SearchBar({query, setQuery, onSearch, loading}){
  return (
    <div className="searchbar">
      <input className="input" placeholder="Brand (Rolex, Omega, Grand Seiko…)" value={query.brand}
        onChange={e=>setQuery({...query, brand:e.target.value})}/>
      <input className="input" placeholder="Model (Datejust, Speedmaster…)" value={query.model}
        onChange={e=>setQuery({...query, model:e.target.value})}/>
      <input className="input" placeholder="Reference (116234, 3570.50…)" value={query.ref}
        onChange={e=>setQuery({...query, ref:e.target.value})}/>
      <button className="button" onClick={onSearch} disabled={loading}>
        {loading ? 'Searching…' : 'Search'}
      </button>
    </div>
  )
}
