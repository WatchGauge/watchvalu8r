import React from 'react'

function safeUrl(u){ try { return new URL(u).href } catch { return null } }

export default function CompsTable({items=[]}){
  const hasRows = items.length>0
  return (
    <div className="card">
      <div className="small">Comparable Sales</div>
      <table className="table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Price</th>
            <th>Date</th>
            <th>Cond.</th>
            <th>Box/Papers</th>
            <th>Source</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {!hasRows && <tr><td colSpan="7" className="small">No comps yet. Use Search or Developer → CSV Upload.</td></tr>}
          {items.map((r,i)=>{
            const price = (r.price && r.currency) ? new Intl.NumberFormat(undefined,{style:'currency',currency:r.currency}).format(r.price) : '—'
            const d = r.date ? new Date(r.date).toISOString().slice(0,10) : '—'
            return (
              <tr key={i}>
                <td>{r.title || `${r.brand||''} ${r.model||''} ${r.reference||''}`}</td>
                <td>{price}</td>
                <td>{d}</td>
                <td>{r.condition || '—'}</td>
                <td>{(r.box_papers===true||r.box_papers==='true'||r.box_papers===1||r.box_papers==='1' || String(r.box_papers).toLowerCase()==='yes') ? 'Yes' : 'No'}</td>
                <td><span className="source-badge">{r.source || '—'}</span></td>
                <td>{safeUrl(r.url) ? <a className="link" href={r.url} target="_blank">View</a> : null}</td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
