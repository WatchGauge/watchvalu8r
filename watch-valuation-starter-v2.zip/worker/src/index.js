import { Router } from 'itty-router'

const router = Router()

function corsHeaders(origin='*'){
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization'
  }
}

router.options('*', (request) => new Response(null, {headers: corsHeaders(request.headers.get('origin')||'*')}))

router.get('/api/health', () => new Response(JSON.stringify({ok:true}), {headers:{'Content-Type':'application/json'}}))

// Proxy ExchangeRate.host to avoid CORS in the browser and centralize caching.
router.get('/api/fx', async (request, env) => {
  const url = new URL(request.url)
  const base = url.searchParams.get('base') || 'USD'
  const symbols = url.searchParams.get('symbols') || 'AUD,EUR,USD'
  const fxUrl = `${env.FX_BASE}?base=${encodeURIComponent(base)}&symbols=${encodeURIComponent(symbols)}`
  const res = await fetch(fxUrl, { cf: { cacheTtl: 3600, cacheEverything: true }})
  const data = await res.json()
  return new Response(JSON.stringify(data), {headers:{'Content-Type':'application/json', ...corsHeaders('*')}})
})

// Simple Supabase REST pass-through for comps (read-only)
router.get('/api/comps', async (request, env) => {
  const url = new URL(request.url)
  const q = new URLSearchParams()
  const limit = url.searchParams.get('limit') || '100'
  // Filters: ilike for fuzzy search
  const brand = url.searchParams.get('brand')
  const model = url.searchParams.get('model')
  const ref = url.searchParams.get('ref')
  if (brand) q.set('brand', `ilike.*${brand}*`)
  if (model) q.set('model', `ilike.*${model}*`)
  if (ref)   q.set('reference', `ilike.*${ref}*`)
  q.set('order', 'date.desc')
  q.set('limit', limit)

  if(!env.SUPABASE_URL || !env.SUPABASE_ANON_KEY){
    return new Response(JSON.stringify({items: []}), {headers:{'Content-Type':'application/json', ...corsHeaders('*')}})
  }
  const endpoint = `${env.SUPABASE_URL}/rest/v1/comps?${q.toString()}`
  const res = await fetch(endpoint, { headers: {
    'apikey': env.SUPABASE_ANON_KEY,
    'Authorization': `Bearer ${env.SUPABASE_ANON_KEY}`,
    'Accept': 'application/json'
  }})
  if(!res.ok){
    const txt = await res.text()
    return new Response(JSON.stringify({error: txt}), {status: res.status, headers:{'Content-Type':'application/json', ...corsHeaders('*')}})
  }
  let items = await res.json()

  // Optional currency normalization to target currency (?to=USD)
  const url2 = new URL(request.url)
  const target = (url2.searchParams.get('to')||'').toUpperCase()
  if (target) {
    const distinct = [...new Set(items.map(i => (i.currency||'').toUpperCase()).filter(Boolean))]
    if (distinct.length) {
      const fxUrl = `/api/fx?base=${encodeURIComponent(target)}&symbols=${encodeURIComponent(distinct.join(','))}`
      const fxRes = await fetch(new URL(fxUrl, request.url))
      if (fxRes.ok) {
        const fx = await fxRes.json()
        const rates = fx?.rates || {}
        items = items.map(i => {
          const c = (i.currency||'').toUpperCase()
          const r = rates[c]
          if (target && c && r) {
            // base=target → rates[c] = units of c per 1 target
            // price_in_target = price / rates[c]
            const p = Number(i.price)
            if (Number.isFinite(p)) {
              i.price = +(p / r).toFixed(2)
              i.currency = target
            }
          }
          return i
        })
      }
    }
  }

  return new Response(JSON.stringify({items}), {headers:{'Content-Type':'application/json', ...corsHeaders('*')}})
})


// Bulk upsert comps — secure behind service key if you enable it.
router.post('/api/comps/bulk', async (request, env) => {
  if (!env.SUPABASE_URL || !env.SUPABASE_ANON_KEY) {
    return new Response(JSON.stringify({error:'Supabase not configured'}), {status:500, headers:{'Content-Type':'application/json', ...corsHeaders('*')}})
  }
  // IMPORTANT: for production use SUPABASE_SERVICE_ROLE to secure writes (not ANON)
  const key = env.SUPABASE_SERVICE_ROLE || ''
  if(!key){
    return new Response(JSON.stringify({error:'Writes disabled: set SUPABASE_SERVICE_ROLE in worker env'}), {status:403, headers:{'Content-Type':'application/json', ...corsHeaders('*')}})
  }
  const items = await request.json().catch(()=>null)
  if (!items || !Array.isArray(items)) return new Response(JSON.stringify({error:'Expected array body'}), {status:400, headers:{'Content-Type':'application/json', ...corsHeaders('*')}})
  const endpoint = `${env.SUPABASE_URL}/rest/v1/comps`
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'apikey': key,
      'Authorization': `Bearer ${key}`,
      'Content-Type':'application/json',
      'Prefer': 'resolution=merge-duplicates'
    },
    body: JSON.stringify(items)
  })
  const data = await res.json().catch(()=>({}))
  return new Response(JSON.stringify(data), {status: res.status, headers:{'Content-Type':'application/json', ...corsHeaders('*')}})
})

router.all('*', () => new Response('Not Found', {status:404}))

export default {
  fetch: (request, env, ctx) => router.handle(request, env, ctx)
}
