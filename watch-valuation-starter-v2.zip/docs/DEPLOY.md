# Deploy Guide (Cloudflare Pages + Worker + Supabase)

## 1) Supabase
1. Create a project → copy Project URL and keys.
2. SQL → run in order:
   - `supabase/schema.sql`
   - `supabase/policies.sql`
   - `supabase/schema_additions.sql`
3. (Optional) Table Editor → import `supabase/sample_data/comps_sample.csv` into `comps`.

## 2) Cloudflare Worker
```bash
cd worker
npm install
# Edit wrangler.toml:
#  SUPABASE_URL = "https://YOUR-PROJECT.supabase.co"
#  SUPABASE_ANON_KEY = "ey..."
#  (optional for writes) SUPABASE_SERVICE_ROLE = "ey..."
npm run dev
# in another shell: curl 'http://127.0.0.1:8787/api/health'
```
- Read endpoint: `/api/comps?brand=rolex&model=datejust&ref=116234&limit=120&to=AUD`
- Bulk upload: `/api/comps/bulk` (requires `SUPABASE_SERVICE_ROLE`)

Deploy:
```bash
wrangler deploy
```

## 3) Frontend (Cloudflare Pages or any host)
```bash
cd app
cp .env.example .env
# Set VITE_API_BASE to your Worker URL, e.g.:
# VITE_API_BASE=https://watch-valuation-worker.YOUR_SUBDOMAIN.workers.dev
npm install
npm run build
npx serve dist  # or deploy to Pages / Netlify / Vercel
```

## 4) eBay / Reddit / Gumtree / Facebook Inputs
- Prefer official APIs or your own exports.
- Normalize to fields in `supabase/schema.sql`. Then:
  - use Bulk Uploader in the UI (CSV → /api/comps/bulk), or
  - build a small ETL that hits `/api/comps/bulk` nightly.

## 5) Production notes
- Turn on CORS only for your domain.
- Limit `/api/comps` page size. Add caching (CF cache + `?since=` windowing).
- Use a real hedonic model when you have enough data (brand/ref dummies, bracelet/dial, etc.).
- Log errors with Cloudflare `console.error` and Supabase logs.
