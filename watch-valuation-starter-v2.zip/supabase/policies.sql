-- Enable RLS and set simple read-only policy for anon, write for service role only.
alter table public.comps enable row level security;

do $$
begin
  if not exists (select 1 from pg_policies where polname = 'read_comps') then
    create policy read_comps on public.comps for select
      using (true);
  end if;
end$$;

-- For writes, you should use service role key via the Worker. Keep anon read-only.
