-- Basic comps table
create table if not exists public.comps (
  id bigserial primary key,
  brand text,
  model text,
  reference text,
  title text,
  price numeric,
  currency text default 'USD',
  date date,
  condition text,
  box_papers boolean default false,
  bracelet text,
  source text,
  url text,
  inserted_at timestamp with time zone default now()
);

-- helpful indexes
create index if not exists idx_comps_brand on public.comps(brand);
create index if not exists idx_comps_model on public.comps(model);
create index if not exists idx_comps_reference on public.comps(reference);
create index if not exists idx_comps_date on public.comps(date desc);
