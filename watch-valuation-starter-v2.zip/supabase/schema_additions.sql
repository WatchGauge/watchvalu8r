-- Hedonic helpers and estimate RPC

-- Map condition to a multiplier (simple heuristic)
create or replace function public.condition_multiplier(cond text)
returns numeric language sql immutable as $$
  select case lower(coalesce(cond,''))
    when 'new' then 1.10
    when 'like new' then 1.06
    when 'very good' then 1.03
    when 'good' then 1.00
    when 'fair' then 0.95
    else 1.00
  end;
$$;

-- Box/Papers bump
create or replace function public.box_papers_multiplier(bp boolean)
returns numeric language sql immutable as $$
  select case when bp then 1.05 else 1.00 end;
$$;

-- Hedonic-adjusted price
create or replace function public.hedonic_price(base_price numeric, cond text, bp boolean)
returns numeric language sql immutable as $$
  select round(base_price * condition_multiplier(cond) * box_papers_multiplier(bp), 2);
$$;

-- Robust stats (median + trimmed range) over a set of prices
create or replace function public.robust_stats(prices numeric[])
returns json language plpgsql immutable as $$
declare
  arr numeric[] := prices;
  n int;
  q1 numeric;
  q3 numeric;
  lo numeric;
  hi numeric;
  trimmed numeric[];
  med numeric;
  p20 numeric;
  p80 numeric;
begin
  n := coalesce(array_length(arr,1), 0);
  if n = 0 then
    return json_build_object('mid', null, 'low', null, 'high', null, 'count', 0);
  end if;

  -- sort
  select array_agg(v order by v) into arr from unnest(arr) v;

  -- quartiles
  select percentile_disc(0.25) within group (order by v),
         percentile_disc(0.75) within group (order by v)
  into q1, q3 from unnest(arr) v;

  lo := q1 - 1.5*(q3-q1);
  hi := q3 + 1.5*(q3-q1);

  select array_agg(v) into trimmed from unnest(arr) v where v between lo and hi;

  if trimmed is null or array_length(trimmed,1)=0 then
    trimmed := arr;
  end if;

  select percentile_disc(0.5) within group (order by v),
         percentile_disc(0.2) within group (order by v),
         percentile_disc(0.8) within group (order by v)
  into med, p20, p80 from unnest(trimmed) v;

  return json_build_object('mid', med, 'low', p20, 'high', p80, 'count', array_length(trimmed,1));
end;
$$;

-- RPC: get comps + hedonic-adjusted estimate for brand/model/ref since a date
create or replace function public.get_comps_estimate(p_brand text default null,
                                                     p_model text default null,
                                                     p_reference text default null,
                                                     p_since date default (now() - interval '365 days'))
returns json language plpgsql security definer as $$
declare
  recs json;
  est json;
begin
  select json_agg(row_to_json(t)) into recs
  from (
    select id, brand, model, reference, title, price,
           currency, date, condition, box_papers, bracelet, source, url,
           hedonic_price(price, condition, box_papers) as hedonic_price
    from public.comps
    where (p_brand is null or brand ilike '%'||p_brand||'%')
      and (p_model is null or model ilike '%'||p_model||'%')
      and (p_reference is null or reference ilike '%'||p_reference||'%')
      and date >= p_since
    order by date desc
    limit 500
  ) t;

  select public.robust_stats(array(select (c->>'hedonic_price')::numeric from json_array_elements(coalesce(recs, '[]'::json)) c))
  into est;

  return json_build_object('items', coalesce(recs, '[]'::json),
                           'estimate', coalesce(est, json_build_object('mid',null,'low',null,'high',null,'count',0)));
end;
$$;
